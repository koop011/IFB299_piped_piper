-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: music_school
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lessonbooking_pendinglessoncontracts_old`
--

DROP TABLE IF EXISTS `lessonbooking_pendinglessoncontracts_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `lessonbooking_pendinglessoncontracts_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(200) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `contract_period` varchar(10) NOT NULL,
  `instrument` varchar(200) NOT NULL,
  `time1` varchar(20) NOT NULL,
  `time2` varchar(20) NOT NULL,
  `time3` varchar(20) NOT NULL,
  `day1` varchar(20) NOT NULL,
  `day2` varchar(20) NOT NULL,
  `day3` varchar(20) NOT NULL,
  `timePeriod1` varchar(20) NOT NULL,
  `timePeriod2` varchar(20) NOT NULL,
  `timePeriod3` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lessonbooking_pendinglessoncontracts_old`
--

LOCK TABLES `lessonbooking_pendinglessoncontracts_old` WRITE;
/*!40000 ALTER TABLE `lessonbooking_pendinglessoncontracts_old` DISABLE KEYS */;
INSERT INTO `lessonbooking_pendinglessoncontracts_old` VALUES (1,'Supa','Glue','1','piano','13:30:00','10:00:00','10:00:00','Wednesday','Friday','Saturday','half','half','full'),(2,'Supa','Glue','4','guitar','08:00:00','09:00:00','13:00:00','Wednesday','Friday','Saturday','full','full','half'),(3,'Supa','Glue','1','keyboard','08:00:00','08:00:00','08:00:00','Monday','Monday','Monday','full','full','full'),(4,'Supa','Glue','1','keyboard','08:00:00','08:00:00','08:00:00','Monday','Monday','Monday','full','full','full'),(5,'Supa','Glue','1','keyboard','08:00:00','08:00:00','08:00:00','Monday','Monday','Monday','full','full','full'),(6,'Supa','Glue','1','keyboard','08:00:00','08:00:00','08:00:00','Monday','Monday','Monday','full','full','full'),(7,'Supa','Glue','1','drums','08:00:00','08:00:00','08:00:00','Monday','Monday','Monday','full','full','full'),(8,'Supa','Glue','2','keyboard','13:00:00','10:00:00','11:00:00','Monday','Wednesday','Friday','half','half','full'),(9,'Supa','Glue','1','keyboard','13:00:00','08:00:00','08:00:00','Monday','Monday','Monday','half','half','full'),(10,'leo','whatever','4','guitar','14:00:00','11:00:00','10:00:00','Monday','Thursday','Tuesday','half','half','full'),(11,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(12,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(13,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(14,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(15,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(16,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(17,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(18,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(19,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(20,'Supa','Glue','1','violin','13:00:00','09:00:00','11:00:00','Monday','Tuesday','Thursday','half','half','full'),(21,'Supa','Glue','3','guitar','10:00:00','11:00:00','16:30:00','Monday','Tuesday','Wednesday','full','half','half'),(22,'Supa','Glue','1','piano','14:30:00','14:30:00','14:00:00','Monday','Monday','Monday','half','half','half');
/*!40000 ALTER TABLE `lessonbooking_pendinglessoncontracts_old` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-30  1:40:56
