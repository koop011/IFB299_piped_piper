-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: music_school
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add account',1,'add_account'),(2,'Can change account',1,'change_account'),(3,'Can delete account',1,'delete_account'),(4,'Can add account manager',2,'add_accountmanager'),(5,'Can change account manager',2,'change_accountmanager'),(6,'Can delete account manager',2,'delete_accountmanager'),(7,'Can add student',3,'add_student'),(8,'Can change student',3,'change_student'),(9,'Can delete student',3,'delete_student'),(10,'Can add teacher data',4,'add_teacherdata'),(11,'Can change teacher data',4,'change_teacherdata'),(12,'Can delete teacher data',4,'delete_teacherdata'),(13,'Can add student data',5,'add_studentdata'),(14,'Can change student data',5,'change_studentdata'),(15,'Can delete student data',5,'delete_studentdata'),(16,'Can add log entry',6,'add_logentry'),(17,'Can change log entry',6,'change_logentry'),(18,'Can delete log entry',6,'delete_logentry'),(19,'Can add permission',7,'add_permission'),(20,'Can change permission',7,'change_permission'),(21,'Can delete permission',7,'delete_permission'),(22,'Can add group',8,'add_group'),(23,'Can change group',8,'change_group'),(24,'Can delete group',8,'delete_group'),(25,'Can add user',9,'add_user'),(26,'Can change user',9,'change_user'),(27,'Can delete user',9,'delete_user'),(28,'Can add content type',10,'add_contenttype'),(29,'Can change content type',10,'change_contenttype'),(30,'Can delete content type',10,'delete_contenttype'),(31,'Can add session',11,'add_session'),(32,'Can change session',11,'change_session'),(33,'Can delete session',11,'delete_session'),(34,'Can add violin hour times',12,'add_violinhourtimes'),(35,'Can change violin hour times',12,'change_violinhourtimes'),(36,'Can delete violin hour times',12,'delete_violinhourtimes'),(37,'Can add electric_guitar',13,'add_electric_guitar'),(38,'Can change electric_guitar',13,'change_electric_guitar'),(39,'Can delete electric_guitar',13,'delete_electric_guitar'),(40,'Can add electric_guitar_hour',13,'add_electric_guitar_hour'),(41,'Can change electric_guitar_hour',13,'change_electric_guitar_hour'),(42,'Can delete electric_guitar_hour',13,'delete_electric_guitar_hour'),(43,'Can add cello',14,'add_cello'),(44,'Can change cello',14,'change_cello'),(45,'Can delete cello',14,'delete_cello'),(46,'Can add clarinet',15,'add_clarinet'),(47,'Can change clarinet',15,'change_clarinet'),(48,'Can delete clarinet',15,'delete_clarinet'),(49,'Can add drums',16,'add_drums'),(50,'Can change drums',16,'change_drums'),(51,'Can delete drums',16,'delete_drums'),(52,'Can add flute',17,'add_flute'),(53,'Can change flute',17,'change_flute'),(54,'Can delete flute',17,'delete_flute'),(55,'Can add guitar',18,'add_guitar'),(56,'Can change guitar',18,'change_guitar'),(57,'Can delete guitar',18,'delete_guitar'),(58,'Can add keyboard',19,'add_keyboard'),(59,'Can change keyboard',19,'change_keyboard'),(60,'Can delete keyboard',19,'delete_keyboard'),(61,'Can add piano',20,'add_piano'),(62,'Can change piano',20,'change_piano'),(63,'Can delete piano',20,'delete_piano'),(64,'Can add saxophone',21,'add_saxophone'),(65,'Can change saxophone',21,'change_saxophone'),(66,'Can delete saxophone',21,'delete_saxophone'),(67,'Can add violin',22,'add_violin'),(68,'Can change violin',22,'change_violin'),(69,'Can delete violin',22,'delete_violin'),(70,'Can add guitar_half_hour',23,'add_guitar_half_hour'),(71,'Can change guitar_half_hour',23,'change_guitar_half_hour'),(72,'Can delete guitar_half_hour',23,'delete_guitar_half_hour'),(73,'Can add guitar_hour',24,'add_guitar_hour'),(74,'Can change guitar_hour',24,'change_guitar_hour'),(75,'Can delete guitar_hour',24,'delete_guitar_hour'),(76,'Can add keyboard_half_hour',25,'add_keyboard_half_hour'),(77,'Can change keyboard_half_hour',25,'change_keyboard_half_hour'),(78,'Can delete keyboard_half_hour',25,'delete_keyboard_half_hour'),(79,'Can add keyboard_hour',26,'add_keyboard_hour'),(80,'Can change keyboard_hour',26,'change_keyboard_hour'),(81,'Can delete keyboard_hour',26,'delete_keyboard_hour'),(82,'Can add piano_half_hour',27,'add_piano_half_hour'),(83,'Can change piano_half_hour',27,'change_piano_half_hour'),(84,'Can delete piano_half_hour',27,'delete_piano_half_hour'),(85,'Can add piano_hour',28,'add_piano_hour'),(86,'Can change piano_hour',28,'change_piano_hour'),(87,'Can delete piano_hour',28,'delete_piano_hour'),(88,'Can add saxophone_half_hour',29,'add_saxophone_half_hour'),(89,'Can change saxophone_half_hour',29,'change_saxophone_half_hour'),(90,'Can delete saxophone_half_hour',29,'delete_saxophone_half_hour'),(91,'Can add saxophone_hour',30,'add_saxophone_hour'),(92,'Can change saxophone_hour',30,'change_saxophone_hour'),(93,'Can delete saxophone_hour',30,'delete_saxophone_hour'),(94,'Can add violin_half_hour',31,'add_violin_half_hour'),(95,'Can change violin_half_hour',31,'change_violin_half_hour'),(96,'Can delete violin_half_hour',31,'delete_violin_half_hour'),(97,'Can add violin_hour',32,'add_violin_hour'),(98,'Can change violin_hour',32,'change_violin_hour'),(99,'Can delete violin_hour',32,'delete_violin_hour'),(100,'Can add cello_half_hour',20,'add_cello_half_hour'),(101,'Can change cello_half_hour',20,'change_cello_half_hour'),(102,'Can delete cello_half_hour',20,'delete_cello_half_hour'),(103,'Can add cello_hour',17,'add_cello_hour'),(104,'Can change cello_hour',17,'change_cello_hour'),(105,'Can delete cello_hour',17,'delete_cello_hour'),(106,'Can add clarinet_half_hour',15,'add_clarinet_half_hour'),(107,'Can change clarinet_half_hour',15,'change_clarinet_half_hour'),(108,'Can delete clarinet_half_hour',15,'delete_clarinet_half_hour'),(109,'Can add clarinet_hour',14,'add_clarinet_hour'),(110,'Can change clarinet_hour',14,'change_clarinet_hour'),(111,'Can delete clarinet_hour',14,'delete_clarinet_hour'),(112,'Can add drums_half_hour',16,'add_drums_half_hour'),(113,'Can change drums_half_hour',16,'change_drums_half_hour'),(114,'Can delete drums_half_hour',16,'delete_drums_half_hour'),(115,'Can add drums_hour',18,'add_drums_hour'),(116,'Can change drums_hour',18,'change_drums_hour'),(117,'Can delete drums_hour',18,'delete_drums_hour'),(118,'Can add electric_guitar_half_hour',19,'add_electric_guitar_half_hour'),(119,'Can change electric_guitar_half_hour',19,'change_electric_guitar_half_hour'),(120,'Can delete electric_guitar_half_hour',19,'delete_electric_guitar_half_hour'),(121,'Can add flute_half_hour',22,'add_flute_half_hour'),(122,'Can change flute_half_hour',22,'change_flute_half_hour'),(123,'Can delete flute_half_hour',22,'delete_flute_half_hour'),(124,'Can add flute_hour',21,'add_flute_hour'),(125,'Can change flute_hour',21,'change_flute_hour'),(126,'Can delete flute_hour',21,'delete_flute_hour'),(127,'Can add pending lesson contracts',33,'add_pendinglessoncontracts'),(128,'Can change pending lesson contracts',33,'change_pendinglessoncontracts'),(129,'Can delete pending lesson contracts',33,'delete_pendinglessoncontracts'),(130,'Can add days',34,'add_days'),(131,'Can change days',34,'change_days'),(132,'Can delete days',34,'delete_days'),(133,'Can add period',35,'add_period'),(134,'Can change period',35,'change_period'),(135,'Can delete period',35,'delete_period'),(136,'Can add pending lesson contracts_new',36,'add_pendinglessoncontracts_new'),(137,'Can change pending lesson contracts_new',36,'change_pendinglessoncontracts_new'),(138,'Can delete pending lesson contracts_new',36,'delete_pendinglessoncontracts_new'),(139,'Can add pending lesson contracts_old',37,'add_pendinglessoncontracts_old'),(140,'Can change pending lesson contracts_old',37,'change_pendinglessoncontracts_old'),(141,'Can delete pending lesson contracts_old',37,'delete_pendinglessoncontracts_old'),(142,'Can add testing',38,'add_testing'),(143,'Can change testing',38,'change_testing'),(144,'Can delete testing',38,'delete_testing');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-30  1:40:56
