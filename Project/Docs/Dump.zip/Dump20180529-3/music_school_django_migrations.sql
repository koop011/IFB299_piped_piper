-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: music_school
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2018-05-11 10:57:18.083347'),(2,'auth','0001_initial','2018-05-11 10:57:19.393013'),(3,'admin','0001_initial','2018-05-11 10:57:19.722673'),(4,'admin','0002_logentry_remove_auto_add','2018-05-11 10:57:19.740685'),(5,'contenttypes','0002_remove_content_type_name','2018-05-11 10:57:20.042355'),(6,'auth','0002_alter_permission_name_max_length','2018-05-11 10:57:20.154930'),(7,'auth','0003_alter_user_email_max_length','2018-05-11 10:57:20.187953'),(8,'auth','0004_alter_user_username_opts','2018-05-11 10:57:20.201962'),(9,'auth','0005_alter_user_last_login_null','2018-05-11 10:57:20.305030'),(10,'auth','0006_require_contenttypes_0002','2018-05-11 10:57:20.311034'),(11,'auth','0007_alter_validators_add_error_messages','2018-05-11 10:57:20.323542'),(12,'auth','0008_alter_user_username_max_length','2018-05-11 10:57:20.584216'),(13,'auth','0009_alter_user_last_name_max_length','2018-05-11 10:57:20.710800'),(14,'contact_page','0001_initial','2018-05-11 10:57:20.781848'),(15,'contact_page','0002_remove_teacherdata_filename','2018-05-11 10:57:20.916643'),(16,'contact_page','0003_teacherdata_filename','2018-05-11 10:57:21.033721'),(17,'contact_page','0004_auto_20180501_2221','2018-05-11 10:57:21.278884'),(18,'loginPage','0001_initial','2018-05-11 10:57:21.385955'),(19,'loginPage','0002_student','2018-05-11 10:57:21.570079'),(20,'loginPage','0003_remove_student_instrument','2018-05-11 10:57:21.725019'),(21,'loginPage','0004_account_gender','2018-05-11 10:57:21.884269'),(22,'sessions','0001_initial','2018-05-11 10:57:21.951313'),(23,'student_account','0001_initial','2018-05-11 10:57:22.000346'),(24,'student_account','0002_auto_20180430_2318','2018-05-11 10:57:22.018359'),(25,'student_account','0003_auto_20180501_0027','2018-05-11 10:57:22.202981'),(26,'student_account','0004_auto_20180501_0030','2018-05-11 10:57:22.221493'),(27,'student_account','0005_auto_20180501_0032','2018-05-11 10:57:22.232501'),(28,'student_account','0006_remove_studentdata_genderradiooptions','2018-05-11 10:57:22.312554'),(29,'student_account','0007_studentdata_genderradiooptions','2018-05-11 10:57:22.421127'),(30,'student_account','0008_auto_20180501_1724','2018-05-11 10:57:22.433135'),(31,'student_account','0009_auto_20180501_1809','2018-05-11 10:57:22.444643'),(32,'student_account','0010_auto_20180501_2249','2018-05-11 10:57:22.520466'),(33,'contact_page','0005_auto_20180516_1833','2018-05-16 08:33:26.228743'),(34,'contact_page','0006_remove_teacherdata_file','2018-05-16 08:36:06.445112'),(35,'student_account','0002_remove_studentdata_instruments','2018-05-20 10:45:21.708098'),(36,'student_account','0003_auto_20180520_2035','2018-05-20 11:07:22.156078'),(37,'student_account','0004_auto_20180520_2051','2018-05-20 11:07:22.197474'),(38,'student_account','0005_auto_20180520_2057','2018-05-20 11:07:22.214429'),(39,'student_account','0006_delete_studentdata','2018-05-20 11:07:22.225400'),(40,'student_account','0007_studentdata','2018-05-20 11:08:19.934436'),(41,'student_account','0008_violinhourtimes','2018-05-20 11:16:19.054754'),(42,'loginPage','0005_delete_accountmanager','2018-05-26 08:41:23.520635'),(43,'lessonBooking','0001_initial','2018-05-26 08:49:33.955278'),(44,'lessonBooking','0002_delete_violinhourtimes','2018-05-26 08:49:34.014120'),(45,'lessonBooking','0003_electric_guitar','2018-05-26 08:52:05.305583'),(46,'lessonBooking','0004_auto_20180526_1855','2018-05-26 08:55:33.359126'),(47,'lessonBooking','0005_cello_clarinet_drums_flute_guitar_keyboard_piano_saxophone_violin','2018-05-26 09:11:45.719128'),(48,'lessonBooking','0006_auto_20180526_1926','2018-05-26 09:26:12.883399'),(49,'student_account','0002_remove_studentdata_instrument','2018-05-27 02:26:47.179304'),(50,'lessonBooking','0007_pendinglessoncontracts','2018-05-27 05:06:30.190264'),(51,'lessonBooking','0008_auto_20180527_1718','2018-05-27 07:18:54.203442'),(52,'student_account','0003_studentdata_instrument','2018-05-27 07:18:54.363521'),(53,'contact_page','0007_remove_teacherdata_subjects','2018-05-27 09:11:05.440706'),(54,'contact_page','0008_teacherdata_electric_guitar','2018-05-27 09:11:05.771822'),(55,'contact_page','0009_auto_20180524_0307','2018-05-27 09:11:06.410058'),(56,'contact_page','0010_auto_20180524_0325','2018-05-27 09:11:08.574941'),(57,'lessonBooking','0009_auto_20180527_2052','2018-05-27 10:52:07.517924'),(58,'lessonBooking','0010_days','2018-05-27 13:55:21.589164'),(59,'lessonBooking','0011_period','2018-05-27 13:58:17.262422'),(60,'lessonBooking','0007_testing','2018-05-29 07:01:20.345934'),(61,'student_account','0002_studentdata_subjects','2018-05-29 07:01:20.601463'),(62,'student_account','0003_auto_20180528_0119','2018-05-29 07:01:20.625978'),(63,'student_account','0004_auto_20180528_0121','2018-05-29 07:01:20.655998'),(64,'lessonBooking','0008_delete_testing','2018-05-29 07:10:06.696843'),(65,'lessonBooking','0009_pendinglessoncontracts_new_pendinglessoncontracts_old','2018-05-29 07:10:17.038419'),(66,'lessonBooking','0002_testing','2018-05-29 07:19:15.207815'),(67,'lessonBooking','0003_delete_testing','2018-05-29 07:19:15.248705'),(68,'lessonBooking','0004_auto_20180529_1705','2018-05-29 07:19:15.410274'),(69,'lessonBooking','0005_pendinglessoncontracts_new_pendinglessoncontracts_old','2018-05-29 07:19:15.626506');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-30  1:40:57
